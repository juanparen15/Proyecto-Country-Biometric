package com.countrysbiometricapi.modules.users.dao;

import java.util.List;

import com.countrysbiometricapi.modules.users.entity.User;

//Interface para el crud de la tabla User Dao
public interface UserDao {
	
	public List<User> findAll();

    public User findById(int id);

    public void save(User user);

    public void deleteById(int id);
}
