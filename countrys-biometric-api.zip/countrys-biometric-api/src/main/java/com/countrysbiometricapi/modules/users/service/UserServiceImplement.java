package com.countrysbiometricapi.modules.users.service;

import org.springframework.stereotype.Service;

import com.countrysbiometricapi.modules.users.dao.UserDao;
import com.countrysbiometricapi.modules.users.entity.User;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

//Clase de service hara de intermediaro entre el DAO y el Controller, Aca se inyectara toda la logica de negocio
@Service
public class UserServiceImplement implements UserService {
	
	@Autowired
    private UserDao userDAO;

	@Override
	public List<User> findAll() {
		List<User> listUsers= userDAO.findAll();
        return listUsers;
	}

	@Override
	public User findById(int id) {
		User user = userDAO.findById(id);
        return user;
	}

	@Override
	public void save(User user) {
		userDAO.save(user);
	}

	@Override
	public void deleteById(int id) {
		userDAO.deleteById(id);
	}
}
