package com.countrysbiometricapi.modules.users.controller;

import org.springframework.web.bind.annotation.RestController;

import com.countrysbiometricapi.modules.users.entity.User;
import com.countrysbiometricapi.modules.users.service.UserService;

import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;

//Indiciamos que es un controlador rest
@RestController
@RequestMapping("/users") //esta sera la raiz de la url, es decir http://localhost:8080/users/
public class UserController {

	//Inyectamos el servicio para poder hacer uso de el
    @Autowired
    private UserService userService;
    
    /*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url http://localhost:8080/users/getUsers*/
    //retornará todos los usuarios
    @GetMapping("/getUsers")
    public List<User> findAll(){
        return userService.findAll();
    }
    
    /*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url + el id de un usuario http://localhost:8080/users/getUser/1*/
    //retornará al usuario con id pasado en la url
    @GetMapping("/getUser/{userId}")
    public User getUser(@PathVariable int userId){
    	
        User user = userService.findById(userId);
        if(user == null) {
            throw new RuntimeException("Usuario no encontrado -"+userId);
        }
        
        return user;
    }
    
    /*Este método se hará cuando por una petición POST (como indica la anotación) se llame a la url http://localhost:8080/users/addUser/  */
    //Este metodo guardará al usuario enviado
    @PostMapping("/addUser")
    public User addUser(@RequestBody User user) {
        user.setIdUser(0);
        userService.save(user);
        return user;
    }
    
    /*Este método se hará cuando por una petición PUT (como indica la anotación) se llame a la url http://localhost:8080/users/updateUser/  */
    //este metodo actualizará al usuario enviado y lo retorna
    @PutMapping("/updateUser")
    public User updateUser(@RequestBody User user) {
        userService.save(user);       
        return user;
    }
    
    /*Este método se hará cuando por una petición DELETE (como indica la anotación) se llame a la url + id del usuario http://localhost:8080/users/deteteUser/1  */
    //Esto método, recibira el id de un usuario por URL y se borrará de la bd.
    @DeleteMapping("/deteteUser/{userId}")
    public String deteteUser(@PathVariable int userId) {

        User user = userService.findById(userId);
        
        if(user == null) {
            throw new RuntimeException("Usuario no encontrado -" + userId);
        }
        userService.deleteById(userId);
       
        return "Usuario eliminado id: "+userId;
    }
	
}
