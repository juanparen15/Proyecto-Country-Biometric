package com.countrysbiometricapi.modules.users.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

//Conexion con la tabla user
@Entity
@Table(name="users")
public class User {
	
	//Mapeo de las columnas de la tabla users
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="ID_USER")
    private int idUser;
	
    @Column(name="NAME")
    private String name;
    
    @Column(name="SURNAME_1")
    private String surname1;

    @Column(name="SURNAME_2")
    private String surname2;
    
    @Column(name="USER_NAME")
    private String userName;
    
    @Column(name="PASSWORD")
    private String password;
    
    @Column(name="STATE")
    private boolean state;

    @Column(name="CREATION_DATE")
    @CreationTimestamp
    private Date creationDate;

    @Column(name="MODIFICATION_DATE")
    @UpdateTimestamp
    private Date modificationDate;
    
    @Column(name="PHONE_NUMBER")
    private String phoneNumber;
    
    
    //Seter y geter de la clase
    public int getIdUser() {
		return idUser;
	}


	public void setIdUser(int idUser) {
		this.idUser = idUser;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getSurname1() {
		return surname1;
	}


	public void setSurname1(String surname1) {
		this.surname1 = surname1;
	}


	public String getSurname2() {
		return surname2;
	}


	public void setSurname2(String surname2) {
		this.surname2 = surname2;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public boolean isState() {
		return state;
	}


	public void setState(boolean state) {
		this.state = state;
	}


	public Date getCreationDate() {
		return creationDate;
	}


	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}


	public Date getModificationDate() {
		return modificationDate;
	}


	public void setModificationDate(Date modificationDate) {
		this.modificationDate = modificationDate;
	}


	public String getPhoneNumber() {
		return phoneNumber;
	}


	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	//Metodo to staring de la entidad
	@Override
	public String toString() {
		return "User [idUser=" + idUser + ", name=" + name + ", surname1=" + surname1 + ", surname2=" + surname2
				+ ", userName=" + userName + ", password=" + password + ", state=" + state + ", creationDate="
				+ creationDate + ", modificationDate=" + modificationDate + ", phoneNumber=" + phoneNumber + "]";
	}
}
