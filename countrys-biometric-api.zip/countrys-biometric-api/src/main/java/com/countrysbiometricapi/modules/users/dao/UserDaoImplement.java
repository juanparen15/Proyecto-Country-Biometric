package com.countrysbiometricapi.modules.users.dao;

import java.util.List;
import javax.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.countrysbiometricapi.modules.users.entity.User;

import org.hibernate.Session;
import org.hibernate.query.Query;

@Repository
public class UserDaoImplement implements UserDao {
	
	@Autowired
    private EntityManager entityManager;
	
	//Metodo que consulta todos los usuarios del sistema
	@Override
	public List<User> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);
        Query<User> theQuery = currentSession.createQuery("from User", User.class);
        List<User> users = theQuery.getResultList();

        return users;
	}
	
	//Metodo que consulta un usuario por id
	@Override
	public User findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
        User user = currentSession.get(User.class, id);

        return user;
	}
	
	//Metodo que realiza la insercion de un usuario
	@Override
	public void save(User user) {
		Session currentSession = entityManager.unwrap(Session.class);
        currentSession.saveOrUpdate(user);  
	}
	
	//Metodo quye se encarga de eliminar un usuario por Id
	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);
		@SuppressWarnings("unchecked") //Se quita advertencia de no conversion explicita
		Query<User> theQuery = currentSession.createQuery("delete from User where id=:idUser");
        theQuery.setParameter("idUser", id);
        theQuery.executeUpdate();
	}
	
	

}
