package com.countrysbiometricapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiApplication {
	
	//Metodo de ejecucion del API Rest
	public static void main(String[] args) {
		SpringApplication.run(ApiApplication.class, args);
	}

}
